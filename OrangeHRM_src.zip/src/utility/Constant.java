
package utility;

public class Constant {

	
	public static final String URL = "https://enterprise-demo.orangehrmlive.com";
	
    public static final String Path_TestData = "D://sumit//Workspace//OrangeHRM//src//testdata//";

    public static final String File_TestData = "TestData.xlsx";
}
