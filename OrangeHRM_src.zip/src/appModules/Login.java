package appModules;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import utility.ExcelUtils;

public class Login {

public static void Execute(WebDriver driver) throws Exception{


	 File file = new File("D:\\sumit\\Workspace\\OrangeHRM\\src\\ObjectRepository\\OR.properties");
	 FileInputStream fis = null;
	fis = new FileInputStream(file);
	Properties prop = new Properties();
		//load properties file			
		try {
			prop.load(fis);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		String login_dtls,Usnm,pwd,login,fulldata,act_msg, home_emp_count;
		login_dtls=prop.getProperty("login_dtls");
		Usnm=prop.getProperty("Usnm");
		pwd=prop.getProperty("pwd");
		login=prop.getProperty("login");
		act_msg=prop.getProperty("act_msg");
		home_emp_count=prop.getProperty("home_emp_count");
	
	Thread.sleep(3000);	
		
	fulldata=driver.findElement(By.xpath(login_dtls)).getText();
	
	
		String s1_prefix,s2_postfix,s3_prefix,s4_postfix,username,password;
		s1_prefix="( 2nd Level Supervisor - Username :"; 
		s2_postfix="| Password : peter.mac )" ;
		
		s3_prefix="( 2nd Level Supervisor - Username : peter.mac | Password :" ;
		s4_postfix=" )";	
		username=fulldata;
		password=fulldata;
		
		System.out.println("data is  :"+ fulldata);
		
		username=username.replace(s1_prefix, "").replace(s2_postfix, "").trim();
		System.out.println("username is :"+username+"--");
		
		password=password.replace(s3_prefix, "").replace(s4_postfix, "").trim();
		System.out.println("password is :"+password+"--");

	
		driver.findElement(By.id(Usnm)).sendKeys(username);
		Thread.sleep(1000);
		 
		driver.findElement(By.id(pwd)).sendKeys(password);
		Thread.sleep(1000);
		
		driver.findElement(By.id(login)).click();
		Thread.sleep(3000);
	
		

		String actualTitle = driver.getTitle();
		System.out.println("Ttile is :"+actualTitle);
		
		String expected_msg="Welcome Peter";
		
		String actual_msg= driver.findElement(By.className(act_msg)).getText();
		System.out.println("actual_msg is :"+actual_msg);
		
		if(actual_msg.equals(expected_msg))
		{
	        System.out.println("Test Pass- Login page");
	    }
	    else
	    {
	        System.out.println("Test Failed- Login page");
	    }

		
		String e_data,e_prefix;
		
		e_data=driver.findElement(By.className(home_emp_count)).getText();
		System.out.println("Total is ::"+ home_emp_count);
		
		e_prefix=" Total : "; 
		
		int e_count;
		
		e_data.replace(e_prefix, "").trim();
		e_count=Integer.parseInt(e_data);
		System.out.println("e_count is :"+e_count+"--");
		
		
		
	//This is to get the values from Excel sheet, passing parameters (Row num &amp; Col num)to getCellData method

//	  String FirstName,LastName,MaritalStatus,Hobby,Cntry,month,date,year,PhoneNumber,Username,Email,AboutYourself,Password,ConfirmPassword;

//	  int rowc, colc;
//	  rowc=ExcelUtils.get_row();
//	  System.out.println("----Row Count  -- "+rowc);
//	  
//	  colc=ExcelUtils.get_col(0);
//	  System.out.println("----colunm Count  -- "+colc);
//	  
//	 String[][] excel_data;
//	 // excel_data=
//			  ExcelUtils.get_all_Data(rowc,colc);
//	
//	  System.out.println("----Printing data -----");
//
//	  
//	  
//	  
//		FirstName = ExcelUtils.getCellData(1, 1);
//		LastName = ExcelUtils.getCellData(1, 2);
//		
//		MaritalStatus=ExcelUtils.getCellData(1, 3);
//		Hobby=ExcelUtils.getCellData(1, 4);
//		Cntry=ExcelUtils.getCellData(1, 5);
//		month=ExcelUtils.getCellData(1, 6);
//		date=ExcelUtils.getCellData(1, 7);
//		year=ExcelUtils.getCellData(1, 8);
//		
//		PhoneNumber= ExcelUtils.getCellData(1, 9);
//		Username= ExcelUtils.getCellData(1, 10);
//		Email= ExcelUtils.getCellData(1,11);
//		AboutYourself= ExcelUtils.getCellData(1, 12);
//		Password= ExcelUtils.getCellData(1, 13);
//		ConfirmPassword= ExcelUtils.getCellData(1, 14);
//
//
//		System.out.println("FirstName -- "+FirstName);
//		System.out.println("LastName -- "+LastName);
//		
//		System.out.println("MaritalStatus -- "+MaritalStatus);
//		System.out.println("Hobby -- "+Hobby);
//		System.out.println("Country -- "+Cntry);
//		System.out.println("month -- "+month);
//		System.out.println("date -- "+date);
//		System.out.println("year -- "+year);
//		
//		System.out.println("PhoneNumber -- "+PhoneNumber);
//		System.out.println("Username -- "+Username);
//		System.out.println("Email -- "+Email);
//		System.out.println("AboutYourself -- "+AboutYourself);
//		System.out.println("Password -- "+Password);
//		System.out.println("ConfirmPassword -- "+ConfirmPassword);
//		
//		
//		driver.findElement(By.xpath("//*[@id='menu-item-374']")).click();
//		Thread.sleep(3000);
//		
//		
//		String actualTitle = driver.getTitle();
//		System.out.println("Ttile is :"+actualTitle);
//		String expectedTitle = "Registration | Demoqa";
//		
//		if(actualTitle.equals(expectedTitle))
//		{
//	        System.out.println("Test Pass- Registration page");
//	    }
//	    else
//	    {
//	        System.out.println("Test Failed- Registration page");
//	    }
//		
//	
//			String L_fnm,L_lnm,L_ms,L_hobby,L_country,L_mnth,L_date,L_year, L_phno,L_unm,L_email,L_urself,L_pwd,L_cpwd;
//		
//			L_fnm= prop.getProperty("FirstName");
//			L_lnm= prop.getProperty("LastName");
//			L_ms=prop.getProperty("MaritalStatus");
//			L_hobby=prop.getProperty("Hobby");
//			L_country=prop.getProperty("Country");
//			L_mnth=prop.getProperty("month");
//			L_date=prop.getProperty("date");
//			L_year=prop.getProperty("year");
//			L_phno= prop.getProperty("PhoneNumber");
//			L_unm= prop.getProperty("Username");
//			L_email= prop.getProperty("Email");
//			L_urself= prop.getProperty("AboutYourself");
//			L_pwd= prop.getProperty("Password");
//			L_cpwd= prop.getProperty("ConfirmPassword");			
//			  
//			
//			 System.out.println("locator fnm  :"+ L_fnm);
//			 System.out.println("Locator Lnm  :"+ L_lnm);
//			  
//			 driver.findElement(By.name(L_fnm)).sendKeys(FirstName);
//			 Thread.sleep(1000);
//			 
//			 driver.findElement(By.name(L_lnm)).sendKeys(LastName);
//			 Thread.sleep(1000);
//			 
//			 driver.findElement(By.xpath(L_ms)).click();
//			 Thread.sleep(1000);
//			 
//			 driver.findElement(By.xpath(L_hobby)).click();
//			 Thread.sleep(1000);
//			 		  
//			 WebElement Country = driver.findElement(By.id(L_country));
//			 Select dropdownc= new Select(Country);
//			 dropdownc.selectByVisibleText("India");			  
//			 WebElement optionc = dropdownc.getFirstSelectedOption();
//			 System.out.println(optionc.getText()); //output "India"
//			 
//			 WebElement Month = driver.findElement(By.id(L_mnth));
//			 Select dropdownm= new Select(Month);
//			 dropdownm.selectByVisibleText("10");			  
//			 WebElement optionm = dropdownm.getFirstSelectedOption();
//			 System.out.println(optionm.getText()); //output "10"
//			 
//			 
//			 WebElement Date = driver.findElement(By.id(L_date));
//			 Select dropdownd= new Select(Date);
//			 dropdownd.selectByVisibleText("5");			  
//			 WebElement optiond = dropdownd.getFirstSelectedOption();
//			 System.out.println(optiond.getText()); //output "5"
//			 
//			 WebElement Year = driver.findElement(By.id(L_year));
//			 Select dropdowny= new Select(Year);
//			 dropdowny.selectByVisibleText("1999");			  
//			 WebElement optiony = dropdowny.getFirstSelectedOption();
//			 System.out.println(optiony.getText()); //output "1999"
//			  
//			 driver.findElement(By.name(L_phno)).sendKeys(PhoneNumber);
//			 Thread.sleep(1000);
//			 
//			 driver.findElement(By.name(L_unm)).sendKeys(Username);
//			 Thread.sleep(1000);
//			 
//			 driver.findElement(By.name(L_email)).sendKeys(Email);
//			 Thread.sleep(1000);
//			 			
//			 
//			 driver.findElement(By.name(L_urself)).sendKeys(AboutYourself);
//			 Thread.sleep(1000);
//			 
//			 driver.findElement(By.name(L_pwd)).sendKeys(Password);
//			 Thread.sleep(1000);
//			 
//			 driver.findElement(By.id(L_cpwd)).sendKeys(ConfirmPassword);
//			 Thread.sleep(1000);
//			 
//			// driver.findElement(By.name("profile_pic_10']")).click();
//			 
//			 			 
//				 Thread.sleep(1000);
			
	}

}


