package appModules;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import utility.ExcelUtils;

public class Registration {

public static void Execute(WebDriver driver) throws Exception{


	 File file = new File("D:\\sumit\\Workspace\\DemoQA\\src\\ObjectRepository\\OR.properties");
	 FileInputStream fis = null;
	fis = new FileInputStream(file);
	Properties prop = new Properties();
		//load properties file			
		try {
			prop.load(fis);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		String reg_link;
		reg_link=prop.getProperty("reglink");
	
	Thread.sleep(3000);
	driver.findElement(By.xpath(reg_link)).click();
	Thread.sleep(3000);
	
	//driver.findElement(By.name("uid")).sendKeys("mngr48976");
	
	
	//This is to get the values from Excel sheet, passing parameters (Row num &amp; Col num)to getCellData method

	String FirstName,LastName,PhoneNumber,Username,Email,AboutYourself,Password,ConfirmPassword;


		FirstName = ExcelUtils.getCellData(1, 1);
		LastName = ExcelUtils.getCellData(1, 2);
		PhoneNumber= ExcelUtils.getCellData(1, 3);
		Username= ExcelUtils.getCellData(1, 4);
		Email= ExcelUtils.getCellData(1,5);
		AboutYourself= ExcelUtils.getCellData(1, 6);
		Password= ExcelUtils.getCellData(1, 7);
		ConfirmPassword= ExcelUtils.getCellData(1, 8);


		System.out.println("FirstName -- "+FirstName);
		System.out.println("LastName -- "+LastName);
		System.out.println("PhoneNumber -- "+PhoneNumber);
		System.out.println("Username -- "+Username);
		System.out.println("Email -- "+Email);
		System.out.println("AboutYourself -- "+AboutYourself);
		System.out.println("Password -- "+Password);
		System.out.println("ConfirmPassword -- "+ConfirmPassword);
		
		
		driver.findElement(By.xpath("//*[@id='menu-item-374']")).click();
		Thread.sleep(3000);
		
		
		String actualTitle = driver.getTitle();
		System.out.println("Ttile is :"+actualTitle);
		String expectedTitle = "Registration | Demoqa";
		
		if(actualTitle.equals(expectedTitle))
		{
	        System.out.println("Test Pass- Registration page");
	    }
	    else
	    {
	        System.out.println("Test Failed- Registration page");
	    }
		
		
	
		
			String L_fnm,L_lnm,L_phno,L_unm,L_email,L_urself,L_pwd,L_cpwd;
		
			L_fnm= prop.getProperty("FirstName");
			L_lnm= prop.getProperty("LastName");
			L_phno= prop.getProperty("PhoneNumber");
			L_unm= prop.getProperty("Username");
			L_email= prop.getProperty("Email");
			L_urself= prop.getProperty("AboutYourself");
			L_pwd= prop.getProperty("Password");
			L_cpwd= prop.getProperty("ConfirmPassword");			
			  
			
			 System.out.println("locator fnm  :"+ L_fnm);
			 System.out.println("Locator Lnm  :"+ L_lnm);
			  
			 driver.findElement(By.name(L_fnm)).sendKeys(FirstName);
			 Thread.sleep(1000);
			 
			 driver.findElement(By.name(L_lnm)).sendKeys(LastName);
			 Thread.sleep(1000);
			 
			 driver.findElement(By.xpath("//input[@value='single']")).click();
			 Thread.sleep(1000);
			 
			 driver.findElement(By.xpath("//input[@value='reading']")).click();
			 Thread.sleep(1000);
			 		  
			 WebElement Country = driver.findElement(By.id("dropdown_7"));
			 Select dropdownc= new Select(Country);
			 dropdownc.selectByVisibleText("India");			  
			 WebElement optionc = dropdownc.getFirstSelectedOption();
			 System.out.println(optionc.getText()); //output "India"
			 
			 WebElement Month = driver.findElement(By.id("mm_date_8"));
			 Select dropdownm= new Select(Month);
			 dropdownm.selectByVisibleText("10");			  
			 WebElement optionm = dropdownm.getFirstSelectedOption();
			 System.out.println(optionm.getText()); //output "10"
			 
			 
			 WebElement Date = driver.findElement(By.id("dd_date_8"));
			 Select dropdownd= new Select(Date);
			 dropdownd.selectByVisibleText("5");			  
			 WebElement optiond = dropdownd.getFirstSelectedOption();
			 System.out.println(optiond.getText()); //output "5"
			 
			 WebElement Year = driver.findElement(By.id("yy_date_8"));
			 Select dropdowny= new Select(Year);
			 dropdowny.selectByVisibleText("1999");			  
			 WebElement optiony = dropdowny.getFirstSelectedOption();
			 System.out.println(optiony.getText()); //output "1999"
			  
			 driver.findElement(By.name(L_phno)).sendKeys(PhoneNumber);
			 Thread.sleep(1000);
			 
			 driver.findElement(By.name(L_unm)).sendKeys(Username);
			 Thread.sleep(1000);
			 
			 driver.findElement(By.name(L_email)).sendKeys(Email);
			 Thread.sleep(1000);
			 
			
			 
			 driver.findElement(By.name(L_urself)).sendKeys(AboutYourself);
			 Thread.sleep(1000);
			 
			 driver.findElement(By.name(L_pwd)).sendKeys(Password);
			 Thread.sleep(1000);
			 
			 driver.findElement(By.id(L_cpwd)).sendKeys(ConfirmPassword);
			 Thread.sleep(1000);
			 
			 driver.findElement(By.name("profile_pic_10']")).click();
			 
			 			 
				 Thread.sleep(1000);
			
	}

}


