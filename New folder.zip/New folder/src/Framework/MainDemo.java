package Framework;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;


//Import Package utility.*
import utility.Constant;
import utility.ExcelUtils;
//Import appModules
import appModules.Registration;

public class MainDemo {

	public static void main(String[] args) throws Exception 
	{
			WebDriver driver;
		  
			ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "Sheet1");							
			//System.setProperty("webdriver.gecko.driver","D:\\sumit\\Selenium_jars\\geckodriver-v0.9.0-win64\\geckodriver.exe");
			System.setProperty("webdriver.chrome.driver","D:\\sumit\\Workspace\\chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
	        options.addArguments("--test-type");
				
			driver= new ChromeDriver(options);
			
			//driver= new FirefoxDriver();			
			driver.manage().window().maximize();
			driver.get(Constant.URL);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);			  

			Registration.Execute(driver);
		    System.out.println("Test");		   
	}

}