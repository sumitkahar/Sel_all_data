
package utility;

public class Constant {

	
	public static final String URL = "http://demoqa.com/";
	
    public static final String Path_TestData = "D://sumit//Workspace//DemoQA//src//testdata//";

    public static final String File_TestData = "TestData.xlsx";
}
