package appModules;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import utility.ExcelUtils;

public class Registration {

public static void Execute(WebDriver driver) throws Exception{


	 File file = new File("D:\\sumit\\Workspace\\DemoQA\\src\\ObjectRepository\\OR.properties");
	 FileInputStream fis = null;
	fis = new FileInputStream(file);
	Properties prop = new Properties();
		//load properties file			
		try {
			prop.load(fis);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		String reg_link;
		reg_link=prop.getProperty("reglink");
	
	
	
	//driver.findElement(By.name("uid")).sendKeys("mngr48976");
	
	
	//This is to get the values from Excel sheet, passing parameters (Row num &amp; Col num)to getCellData method

	  String FirstName,LastName,MaritalStatus,Hobby,Cntry,month,date,year,PhoneNumber,Username,Email,AboutYourself,Password,ConfirmPassword;

	  int rowc, colc;
	  rowc=ExcelUtils.get_row();
	  System.out.println("----Row Count  -- "+rowc);
	  
	  colc=ExcelUtils.get_col(0);
	  System.out.println("\n ----colunm Count  -- "+colc);

	  System.out.println("----Printing data -----");

// while row -- navigate from 1st to last-- perform following operations	  
	  int i=1;
	  while(i<=rowc)
	  {
		  System.out.println("i="+i);
		  
		FirstName = ExcelUtils.getCellData(i, 1);
		LastName = ExcelUtils.getCellData(i, 2);
		
		MaritalStatus=ExcelUtils.getCellData(i, 3);
		Hobby=ExcelUtils.getCellData(i, 4);
		Cntry=ExcelUtils.getCellData(i, 5);
		month=ExcelUtils.getCellData(i, 6);
		date=ExcelUtils.getCellData(i, 7);
		year=ExcelUtils.getCellData(i, 8);
		
		PhoneNumber= ExcelUtils.getCellData(i, 9);
		Username= ExcelUtils.getCellData(i, 10);
		Email= ExcelUtils.getCellData(i,11);
		AboutYourself= ExcelUtils.getCellData(i, 12);
		Password= ExcelUtils.getCellData(i, 13);
		ConfirmPassword= ExcelUtils.getCellData(i, 14);


		System.out.println("FirstName --"+FirstName);
		System.out.println("LastName --"+LastName);
		
		System.out.println("MaritalStatus --"+MaritalStatus);
		System.out.println("Hobby --"+Hobby);
		System.out.println("Country --"+Cntry);
		System.out.println("month --"+month);
		System.out.println("date --"+date);
		System.out.println("year --"+year);
		
		System.out.println("PhoneNumber --"+PhoneNumber);
		System.out.println("Username --"+Username);
		System.out.println("Email --"+Email);
		System.out.println("AboutYourself --"+AboutYourself);
		System.out.println("Password --"+Password);
		System.out.println("ConfirmPassword --"+ConfirmPassword);
		
		Thread.sleep(3000);
		driver.findElement(By.xpath(reg_link)).click();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//*[@id='menu-item-374']")).click();
		Thread.sleep(3000);
		
		
		String actualTitle = driver.getTitle();
		System.out.println("Ttile is :"+actualTitle);
		String expectedTitle = "Registration | Demoqa";
		
		if(actualTitle.equals(expectedTitle))
		{
	        System.out.println("Test Pass- Registration page");
	    }
	    else
	    {
	        System.out.println("Test Failed- Registration page");
	    }
		
		
		/*MaritalStatus=//input[@value='single']
				Hobby=//input[@value='reading']
				Country=dropdown_7
				month=mm_date_8
				date=dd_date_8
				year=yy_date_8*/
		
			String L_fnm,L_lnm,L_ms,L_hobby,L_country,L_mnth,L_date,L_year, L_phno,L_unm,L_email,L_urself,L_pwd,L_cpwd;
		
			L_fnm= prop.getProperty("FirstName");
			L_lnm= prop.getProperty("LastName");
			
			// Status
			if(MaritalStatus.equalsIgnoreCase("Married"))			
			{
				L_ms=prop.getProperty("Ms_Married");
			}
			else if(MaritalStatus.equalsIgnoreCase("Divorced"))
			{
				L_ms=prop.getProperty("Ms_Divorced");
			}
			else
			{
				L_ms=prop.getProperty("Ms_Single");

			}
			
			//Hobby
			
			if(Hobby.equalsIgnoreCase("Dance"))			
			{
				L_hobby=prop.getProperty("Hobby_Dance");
				System.out.println("Hobby_Dance");
			}
			else if(Hobby.equalsIgnoreCase("Reading"))
			{
				L_hobby=prop.getProperty("Hobby_Reading");
				System.out.println("Hobby_Reading");
			}
			else
			{
				L_hobby=prop.getProperty("Hobby_Cricket");
				System.out.println("Hobby_Cricket");

			}
			

			L_country=prop.getProperty("Country");
			L_mnth=prop.getProperty("month");
			L_date=prop.getProperty("date");
			L_year=prop.getProperty("year");
			L_phno= prop.getProperty("PhoneNumber");
			L_unm= prop.getProperty("Username");
			L_email= prop.getProperty("Email");
			L_urself= prop.getProperty("AboutYourself");
			L_pwd= prop.getProperty("Password");
			L_cpwd= prop.getProperty("ConfirmPassword");			
			  
			
			 System.out.println("locator fnm  :"+ L_fnm);
			 System.out.println("Locator Lnm  :"+ L_lnm);
			  
			 driver.findElement(By.name(L_fnm)).sendKeys(FirstName);
			 Thread.sleep(1000);
			 
			 driver.findElement(By.name(L_lnm)).sendKeys(LastName);
			 Thread.sleep(1000);
			 
			 driver.findElement(By.xpath(L_ms)).click();
			 Thread.sleep(1000);
			 			 
			 driver.findElement(By.xpath(L_hobby)).click();
			 Thread.sleep(1000);
			 		  
			 WebElement Country = driver.findElement(By.id(L_country));
			 Select dropdownc= new Select(Country);
			 dropdownc.selectByVisibleText(Cntry);			  
			 WebElement optionc = dropdownc.getFirstSelectedOption();
			 System.out.println(optionc.getText()); //output "India"
			 
			 WebElement Month = driver.findElement(By.id(L_mnth));
			 Select dropdownm= new Select(Month);
			 dropdownm.selectByVisibleText(month);			  
			 WebElement optionm = dropdownm.getFirstSelectedOption();
			 System.out.println(optionm.getText()); //output "month-10"
			 
			 
			 WebElement Date = driver.findElement(By.id(L_date));
			 Select dropdownd= new Select(Date);
			 dropdownd.selectByVisibleText(date);			  
			 WebElement optiond = dropdownd.getFirstSelectedOption();
			 System.out.println(optiond.getText()); //output "date-5"
			 
			 WebElement Year = driver.findElement(By.id(L_year));
			 Select dropdowny= new Select(Year);
			 dropdowny.selectByVisibleText(year);			  
			 WebElement optiony = dropdowny.getFirstSelectedOption();
			 System.out.println(optiony.getText()); //output "year-1999"
			  
			 driver.findElement(By.name(L_phno)).sendKeys(PhoneNumber);
			 Thread.sleep(1000);
			 
			 driver.findElement(By.name(L_unm)).sendKeys(Username);
			 Thread.sleep(1000);
			 
			 driver.findElement(By.name(L_email)).sendKeys(Email);
			 Thread.sleep(1000);
			 			
			 
			 driver.findElement(By.name(L_urself)).sendKeys(AboutYourself);
			 Thread.sleep(1000);
			 
			 driver.findElement(By.name(L_pwd)).sendKeys(Password);
			 Thread.sleep(1000);
			 
			 driver.findElement(By.id(L_cpwd)).sendKeys(ConfirmPassword);
			 Thread.sleep(1000);
			 
			// driver.findElement(By.name("profile_pic_10']")).click();
			 
			 			 
				 Thread.sleep(3000);
				 i++;
	  }
			
	}

}


